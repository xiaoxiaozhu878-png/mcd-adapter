# Aster 麦当劳 MCP 适配器

这是一个个人使用的 OAuth 2.1 + PKCE 适配器，让 ChatGPT 自定义 MCP 可以连接麦当劳中国官方 MCP。

## 默认安全设置

- 麦当劳 MCP Token 只保存在部署平台的隐藏环境变量中。
- 上游地址被锁定为 `https://mcp.mcd.cn`，不会把 Token 转发到其他域名。
- `ALLOW_ORDER_CREATION=false`：默认阻止创建订单、支付、领券绑定、地址写入等操作。
- 只接受 ChatGPT/OpenAI 官方 HTTPS 回调地址。
- OAuth 授权码使用 PKCE S256，访问令牌为短期签名令牌。
- 服务不记录请求内容、密码、Token 或地址等个人信息。

## 部署到 Render

1. 把本文件夹上传到一个新的 GitHub 仓库；不要上传 `.env`。
2. 在 Render 选择 **New > Blueprint**，连接该仓库。
3. Render 会要求填写两个隐藏值：
   - `MCD_MCP_TOKEN`：在麦当劳开放平台生成的 Token。
   - `ADAPTER_OWNER_PASSWORD`：新设一个至少 12 位、只用于连接 ChatGPT 的密码。
4. 等待部署完成，打开 `https://你的服务.onrender.com/healthz`。看到 `{"ok":true,"write_actions_enabled":false}` 即成功。

`OAUTH_SIGNING_SECRET` 会由 Render 自动生成，无需手填。Render 也会自动提供 `RENDER_EXTERNAL_URL`。

## 添加到 ChatGPT

在 ChatGPT 网页版开启开发者模式，创建自定义 MCP：

- MCP URL：`https://你的服务.onrender.com/mcp`
- 身份验证：OAuth

连接时页面会要求输入 `ADAPTER_OWNER_PASSWORD`。不要在 ChatGPT 对话里发送麦当劳 Token 或该密码。

## 本地检查

```bash
npm ci
npm test
```

本项目不包含第三方运行时依赖，仅使用 Node.js 标准库。

## 重要限制

这是独立的个人适配器，不是麦当劳或 OpenAI 官方发布的软件。麦当劳官方 MCP 的工具名称如有变化，写入拦截名单也需要相应更新。保持 `ALLOW_ORDER_CREATION=false` 最安全；若未来要开放加入购物车或下单，应先逐个核对工具并保留最终人工确认。
