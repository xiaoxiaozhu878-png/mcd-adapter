import crypto from "node:crypto";

const b64u = (value) => Buffer.from(value).toString("base64url");
const parseB64u = (value) => Buffer.from(value, "base64url");

export function createTokenService(secret, now = () => Date.now()) {
  if (!secret || Buffer.byteLength(secret) < 32) {
    throw new Error("OAUTH_SIGNING_SECRET must contain at least 32 bytes");
  }

  const sign = (data) => crypto.createHmac("sha256", secret).update(data).digest("base64url");

  function issue(type, payload, ttlSeconds) {
    const body = b64u(JSON.stringify({
      ...payload,
      typ: type,
      iat: Math.floor(now() / 1000),
      exp: Math.floor(now() / 1000) + ttlSeconds,
      jti: crypto.randomUUID()
    }));
    return `${body}.${sign(body)}`;
  }

  function verify(token, expectedType) {
    if (typeof token !== "string") throw new Error("invalid token");
    const [body, signature, extra] = token.split(".");
    if (!body || !signature || extra) throw new Error("invalid token");
    const expected = sign(body);
    const a = Buffer.from(signature);
    const b = Buffer.from(expected);
    if (a.length !== b.length || !crypto.timingSafeEqual(a, b)) throw new Error("invalid token");
    let payload;
    try { payload = JSON.parse(parseB64u(body).toString("utf8")); } catch { throw new Error("invalid token"); }
    if (payload.typ !== expectedType || payload.exp < Math.floor(now() / 1000)) throw new Error("invalid token");
    return payload;
  }

  return { issue, verify };
}

export function verifyPkce(verifier, challenge) {
  if (!/^[A-Za-z0-9._~-]{43,128}$/.test(verifier || "")) return false;
  const actual = crypto.createHash("sha256").update(verifier).digest("base64url");
  const a = Buffer.from(actual);
  const b = Buffer.from(challenge || "");
  return a.length === b.length && crypto.timingSafeEqual(a, b);
}

export function safeEqual(a, b) {
  const ah = crypto.createHash("sha256").update(String(a || "")).digest();
  const bh = crypto.createHash("sha256").update(String(b || "")).digest();
  return crypto.timingSafeEqual(ah, bh);
}
