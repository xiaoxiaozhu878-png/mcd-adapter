const explicitWriteTools = new Set([
  "create-order",
  "mall-create-order",
  "auto-bind-coupons",
  "delivery-create-address"
]);

const riskyWords = /(^|[-_.])(create|update|delete|remove|bind|redeem|exchange|pay|submit|cancel)([-_.]|$)/i;

export function getCalledTool(body) {
  if (!body || typeof body !== "object" || Array.isArray(body)) return null;
  if (body.method !== "tools/call") return null;
  return typeof body.params?.name === "string" ? body.params.name : null;
}

export function isWriteTool(toolName) {
  if (!toolName) return false;
  return explicitWriteTools.has(toolName.toLowerCase()) || riskyWords.test(toolName);
}

export function checkBodyPolicy(body, allowWrites = false) {
  if (allowWrites) return { allowed: true };
  const requests = Array.isArray(body) ? body : [body];
  for (const request of requests) {
    const tool = getCalledTool(request);
    if (isWriteTool(tool)) {
      return { allowed: false, tool, id: request?.id ?? null };
    }
  }
  return { allowed: true };
}
