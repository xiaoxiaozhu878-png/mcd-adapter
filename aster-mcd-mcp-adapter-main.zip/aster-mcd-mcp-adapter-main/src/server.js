import http from "node:http";
import { Readable } from "node:stream";
import { URL, URLSearchParams } from "node:url";
import { createTokenService, safeEqual, verifyPkce } from "./tokens.js";
import { checkBodyPolicy } from "./policy.js";

const PORT = Number(process.env.PORT || 3000);
const UPSTREAM = new URL(process.env.MCD_MCP_URL || "https://mcp.mcd.cn");
const MCP_TOKEN = process.env.MCD_MCP_TOKEN;
const OWNER_PASSWORD = process.env.ADAPTER_OWNER_PASSWORD;
const SIGNING_SECRET = process.env.OAUTH_SIGNING_SECRET;
const ALLOW_WRITES = process.env.ALLOW_ORDER_CREATION === "true";
const PUBLIC_BASE = (process.env.PUBLIC_BASE_URL || process.env.RENDER_EXTERNAL_URL || `http://localhost:${PORT}`).replace(/\/$/, "");
const MAX_BODY_BYTES = 1024 * 1024;
const usedCodes = new Map();

if (UPSTREAM.protocol !== "https:" || UPSTREAM.hostname !== "mcp.mcd.cn" || UPSTREAM.username || UPSTREAM.password) {
  throw new Error("MCD_MCP_URL must point to https://mcp.mcd.cn");
}
if (!MCP_TOKEN) throw new Error("MCD_MCP_TOKEN is required");
if (!OWNER_PASSWORD || OWNER_PASSWORD.length < 12) throw new Error("ADAPTER_OWNER_PASSWORD must be at least 12 characters");
const tokens = createTokenService(SIGNING_SECRET);

const json = (res, status, body, headers = {}) => {
  const data = JSON.stringify(body);
  res.writeHead(status, { "content-type": "application/json; charset=utf-8", "content-length": Buffer.byteLength(data), ...headers });
  res.end(data);
};

const html = (res, status, body) => {
  res.writeHead(status, { "content-type": "text/html; charset=utf-8", "content-security-policy": "default-src 'none'; style-src 'unsafe-inline'; form-action 'self'; frame-ancestors 'none'", "x-frame-options": "DENY", "referrer-policy": "no-referrer", "cache-control": "no-store" });
  res.end(body);
};

const esc = (value) => String(value || "").replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));

async function readBody(req) {
  const chunks = [];
  let total = 0;
  for await (const chunk of req) {
    total += chunk.length;
    if (total > MAX_BODY_BYTES) throw Object.assign(new Error("request too large"), { status: 413 });
    chunks.push(chunk);
  }
  return Buffer.concat(chunks);
}

async function readForm(req) {
  const raw = await readBody(req);
  return new URLSearchParams(raw.toString("utf8"));
}

function isAllowedRedirect(uri) {
  try {
    const u = new URL(uri);
    const host = u.hostname.toLowerCase();
    return u.protocol === "https:" && (host === "chatgpt.com" || host.endsWith(".chatgpt.com") || host === "openai.com" || host.endsWith(".openai.com"));
  } catch { return false; }
}

function verifyClient(clientId, redirectUri) {
  const client = tokens.verify(clientId, "client");
  if (!client.redirect_uris?.includes(redirectUri) || !isAllowedRedirect(redirectUri)) throw new Error("invalid client");
  return client;
}

function oauthError(res, status, error, description) {
  json(res, status, { error, error_description: description }, { "cache-control": "no-store", pragma: "no-cache" });
}

function metadata() {
  return {
    issuer: PUBLIC_BASE,
    authorization_endpoint: `${PUBLIC_BASE}/authorize`,
    token_endpoint: `${PUBLIC_BASE}/token`,
    registration_endpoint: `${PUBLIC_BASE}/register`,
    response_types_supported: ["code"],
    grant_types_supported: ["authorization_code", "refresh_token"],
    token_endpoint_auth_methods_supported: ["none"],
    code_challenge_methods_supported: ["S256"],
    scopes_supported: ["mcp"],
    authorization_response_iss_parameter_supported: true
  };
}

function resourceMetadata() {
  return { resource: `${PUBLIC_BASE}/mcp`, authorization_servers: [PUBLIC_BASE], bearer_methods_supported: ["header"], scopes_supported: ["mcp"] };
}

function authParams(search) {
  return {
    client_id: search.get("client_id") || "",
    redirect_uri: search.get("redirect_uri") || "",
    response_type: search.get("response_type") || "",
    state: search.get("state") || "",
    code_challenge: search.get("code_challenge") || "",
    code_challenge_method: search.get("code_challenge_method") || "",
    resource: search.get("resource") || `${PUBLIC_BASE}/mcp`
  };
}

function validateAuth(p) {
  if (p.response_type !== "code") throw new Error("unsupported response type");
  verifyClient(p.client_id, p.redirect_uri);
  if (p.code_challenge_method !== "S256" || !/^[A-Za-z0-9_-]{43}$/.test(p.code_challenge)) throw new Error("PKCE S256 is required");
  if (p.resource !== `${PUBLIC_BASE}/mcp`) throw new Error("invalid resource");
}

function loginPage(p, error = "") {
  const hidden = Object.entries(p).map(([k, v]) => `<input type="hidden" name="${esc(k)}" value="${esc(v)}">`).join("");
  return `<!doctype html><html lang="zh-CN"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>连接 Aster 麦当劳助手</title><style>body{font-family:system-ui;background:#fff7e8;margin:0;padding:24px;color:#222}.card{max-width:420px;margin:12vh auto;background:#fff;padding:28px;border-radius:22px;box-shadow:0 10px 40px #0001}input,button{box-sizing:border-box;width:100%;padding:14px;border-radius:12px;font-size:16px}input{border:1px solid #ccc;margin:12px 0}button{border:0;background:#ffbc0d;font-weight:700}.err{color:#b00020}small{display:block;margin-top:14px;color:#666}</style><div class="card"><h2>Aster 帮你挑麦当劳</h2><p>输入你在部署时设置的连接密码。</p>${error ? `<p class="err">${esc(error)}</p>` : ""}<form method="post" action="/authorize">${hidden}<input name="password" type="password" autocomplete="current-password" required placeholder="连接密码"><button type="submit">允许 ChatGPT 连接</button></form><small>这里不需要填写麦当劳 Token，也不会显示它。</small></div></html>`;
}

function bearer(req) {
  const match = /^Bearer (.+)$/i.exec(req.headers.authorization || "");
  if (!match) return null;
  try {
    const access = tokens.verify(match[1], "access");
    return access.aud === `${PUBLIC_BASE}/mcp` ? access : null;
  } catch { return null; }
}

async function proxyMcp(req, res) {
  if (!bearer(req)) {
    return json(res, 401, { error: "invalid_token" }, { "www-authenticate": `Bearer resource_metadata="${PUBLIC_BASE}/.well-known/oauth-protected-resource/mcp"` });
  }
  let body;
  if (req.method === "POST") {
    body = await readBody(req);
    try {
      const parsed = JSON.parse(body.toString("utf8"));
      const policy = checkBodyPolicy(parsed, ALLOW_WRITES);
      if (!policy.allowed) {
        return json(res, 200, { jsonrpc: "2.0", id: policy.id, error: { code: -32001, message: `安全模式已阻止写入操作：${policy.tool}` } });
      }
    } catch (error) {
      if (error.status) throw error;
    }
  }
  const target = new URL(UPSTREAM);
  target.search = new URL(req.url, PUBLIC_BASE).search;
  const headers = {
    authorization: `Bearer ${MCP_TOKEN}`,
    accept: req.headers.accept || "application/json, text/event-stream",
    "user-agent": "aster-mcd-mcp-adapter/1.0"
  };
  if (req.headers["content-type"]) headers["content-type"] = req.headers["content-type"];
  if (req.headers["mcp-session-id"]) headers["mcp-session-id"] = req.headers["mcp-session-id"];
  if (req.headers["last-event-id"]) headers["last-event-id"] = req.headers["last-event-id"];
  const upstream = await fetch(target, { method: req.method, headers, body: ["GET", "HEAD"].includes(req.method) ? undefined : body, redirect: "manual" });
  const outHeaders = {};
  for (const key of ["content-type", "cache-control", "mcp-session-id", "retry-after"]) {
    const value = upstream.headers.get(key);
    if (value) outHeaders[key] = value;
  }
  res.writeHead(upstream.status, outHeaders);
  if (upstream.body) Readable.fromWeb(upstream.body).pipe(res); else res.end();
}

const server = http.createServer(async (req, res) => {
  try {
    const url = new URL(req.url, PUBLIC_BASE);
    if (req.method === "GET" && url.pathname === "/healthz") return json(res, 200, { ok: true, write_actions_enabled: ALLOW_WRITES });
    if (req.method === "GET" && ["/.well-known/oauth-authorization-server", "/.well-known/openid-configuration"].includes(url.pathname)) return json(res, 200, metadata());
    if (req.method === "GET" && ["/.well-known/oauth-protected-resource", "/.well-known/oauth-protected-resource/mcp"].includes(url.pathname)) return json(res, 200, resourceMetadata());

    if (req.method === "POST" && url.pathname === "/register") {
      const raw = await readBody(req);
      let input;
      try { input = JSON.parse(raw.toString("utf8")); } catch { return oauthError(res, 400, "invalid_client_metadata", "JSON body required"); }
      const redirects = input.redirect_uris;
      if (!Array.isArray(redirects) || redirects.length < 1 || redirects.length > 10 || !redirects.every(isAllowedRedirect)) return oauthError(res, 400, "invalid_redirect_uri", "Only official ChatGPT/OpenAI HTTPS callbacks are allowed");
      const clientId = tokens.issue("client", { redirect_uris: redirects }, 365 * 24 * 3600);
      return json(res, 201, { client_id: clientId, client_id_issued_at: Math.floor(Date.now() / 1000), token_endpoint_auth_method: "none", redirect_uris: redirects, grant_types: ["authorization_code", "refresh_token"], response_types: ["code"] });
    }

    if (req.method === "GET" && url.pathname === "/authorize") {
      const p = authParams(url.searchParams);
      try { validateAuth(p); } catch (e) { return html(res, 400, loginPage(p, e.message)); }
      return html(res, 200, loginPage(p));
    }

    if (req.method === "POST" && url.pathname === "/authorize") {
      const form = await readForm(req);
      const p = authParams(form);
      try { validateAuth(p); } catch (e) { return html(res, 400, loginPage(p, e.message)); }
      if (!safeEqual(form.get("password"), OWNER_PASSWORD)) return html(res, 401, loginPage(p, "密码不对，请再试一次。"));
      const code = tokens.issue("code", { client_id: p.client_id, redirect_uri: p.redirect_uri, code_challenge: p.code_challenge, resource: p.resource }, 300);
      const callback = new URL(p.redirect_uri);
      callback.searchParams.set("code", code);
      if (p.state) callback.searchParams.set("state", p.state);
      callback.searchParams.set("iss", PUBLIC_BASE);
      res.writeHead(302, { location: callback.toString(), "cache-control": "no-store" });
      return res.end();
    }

    if (req.method === "POST" && url.pathname === "/token") {
      const form = await readForm(req);
      const grant = form.get("grant_type");
      if (grant === "authorization_code") {
        let code;
        try { code = tokens.verify(form.get("code"), "code"); } catch { return oauthError(res, 400, "invalid_grant", "Invalid or expired code"); }
        if (usedCodes.has(code.jti)) return oauthError(res, 400, "invalid_grant", "Code already used");
        if (code.client_id !== form.get("client_id") || code.redirect_uri !== form.get("redirect_uri") || !verifyPkce(form.get("code_verifier"), code.code_challenge)) return oauthError(res, 400, "invalid_grant", "Code validation failed");
        usedCodes.set(code.jti, code.exp);
        const access = tokens.issue("access", { client_id: code.client_id, aud: code.resource, scope: "mcp" }, 3600);
        const refresh = tokens.issue("refresh", { client_id: code.client_id, aud: code.resource, scope: "mcp" }, 30 * 24 * 3600);
        return json(res, 200, { access_token: access, token_type: "Bearer", expires_in: 3600, refresh_token: refresh, scope: "mcp" }, { "cache-control": "no-store", pragma: "no-cache" });
      }
      if (grant === "refresh_token") {
        let refresh;
        try { refresh = tokens.verify(form.get("refresh_token"), "refresh"); } catch { return oauthError(res, 400, "invalid_grant", "Invalid or expired refresh token"); }
        if (refresh.client_id !== form.get("client_id")) return oauthError(res, 400, "invalid_grant", "Client mismatch");
        const access = tokens.issue("access", { client_id: refresh.client_id, aud: refresh.aud, scope: "mcp" }, 3600);
        return json(res, 200, { access_token: access, token_type: "Bearer", expires_in: 3600, scope: "mcp" }, { "cache-control": "no-store", pragma: "no-cache" });
      }
      return oauthError(res, 400, "unsupported_grant_type", "Unsupported grant type");
    }

    if (["GET", "POST", "DELETE"].includes(req.method) && url.pathname === "/mcp") return proxyMcp(req, res);
    json(res, 404, { error: "not_found" });
  } catch (error) {
    console.error(`[adapter] ${error.name}: ${error.message}`);
    json(res, error.status || 500, { error: error.status ? error.message : "internal_error" });
  }
});

setInterval(() => {
  const now = Math.floor(Date.now() / 1000);
  for (const [id, exp] of usedCodes) if (exp < now) usedCodes.delete(id);
}, 60_000).unref();

server.listen(PORT, "0.0.0.0", () => console.log(`[adapter] listening on port ${PORT}; write actions: ${ALLOW_WRITES ? "enabled" : "blocked"}`));
