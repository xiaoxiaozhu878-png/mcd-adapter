import test from "node:test";
import assert from "node:assert/strict";
import crypto from "node:crypto";
import { createTokenService, verifyPkce } from "../src/tokens.js";

test("signed token round trip and tamper rejection", () => {
  const service = createTokenService("x".repeat(32), () => 1_000_000);
  const token = service.issue("access", { aud: "demo" }, 60);
  assert.equal(service.verify(token, "access").aud, "demo");
  assert.throws(() => service.verify(`${token}x`, "access"));
  assert.throws(() => service.verify(token, "refresh"));
});

test("expired token is rejected", () => {
  let now = 1_000_000;
  const service = createTokenService("x".repeat(32), () => now);
  const token = service.issue("access", {}, 1);
  now += 2_000;
  assert.throws(() => service.verify(token, "access"));
});

test("PKCE S256 validation", () => {
  const verifier = "a".repeat(43);
  const challenge = crypto.createHash("sha256").update(verifier).digest("base64url");
  assert.equal(verifyPkce(verifier, challenge), true);
  assert.equal(verifyPkce(`${verifier}b`, challenge), false);
});
