import test from "node:test";
import assert from "node:assert/strict";
import { checkBodyPolicy, isWriteTool } from "../src/policy.js";

test("query tools remain available", () => {
  assert.equal(isWriteTool("search-restaurants"), false);
  assert.deepEqual(checkBodyPolicy({ method: "tools/call", params: { name: "get-menu" } }), { allowed: true });
});

test("order and coupon mutations are blocked", () => {
  for (const name of ["create-order", "mall-create-order", "auto-bind-coupons", "delivery-create-address", "coupon-redeem"]) {
    assert.equal(checkBodyPolicy({ jsonrpc: "2.0", id: 7, method: "tools/call", params: { name } }).allowed, false);
  }
});

test("writes can be enabled explicitly", () => {
  assert.deepEqual(checkBodyPolicy({ method: "tools/call", params: { name: "create-order" } }, true), { allowed: true });
});
